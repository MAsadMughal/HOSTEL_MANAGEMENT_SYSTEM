package com.SpringBootProject.SpringBootProject.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.SpringBootProject.SpringBootProject.model.Student;

public interface StudentDao extends JpaRepository<Student, String> {
	Student findByStudentId(String studentId);
	List<Student> getByStudentId(String studentId);
	List<Student> findByhostelId(String hostelId);
	List<Student> findByhostelIdAndRoomId(String hostelId,int roomId);
	boolean existsByhostelIdAndRoomId(String hostelId, int roomId);
	
}
