package com.SpringBootProject.SpringBootProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBootProject.SpringBootProject.model.Room;
import com.SpringBootProject.SpringBootProject.services.RoomService;

@RestController
@CrossOrigin
public class RoomsController {

	@Autowired
	private RoomService roomService;

	@PostMapping("/room")
	public Room addRoom(@RequestBody Room r) {
		System.out.print(r);
		return this.roomService.AddRoom(r);
	}

	@GetMapping("/room")
	public List<Room> getRooms() {
		return this.roomService.getRooms();
	}

	@GetMapping("/Rooms/hostelId")
	public List<Room> getRoomsByHostel(@RequestParam String hostelId) {
		return this.roomService.getRoomsByHostel(hostelId);
	}

	@GetMapping("/room/hostelId/roomId")
	public List<Room> getRoomsByhostelAndRoom(@RequestParam String hostelId, @RequestParam int roomId) {
		return this.roomService.getByhostelIdAndRoomId(hostelId, roomId);
	}

	@GetMapping("/Editroom/hostelId/roomId")
	public Room findRoomsByhostelAndRoom(@RequestParam String hostelId, @RequestParam int roomId) {
		return this.roomService.findByhostelIdAndRoomId(hostelId, roomId);
	}

	@PutMapping("/editRoom")
	public Room editRoom(@RequestBody Room r) {
		return this.roomService.EditRoom(r);
	}

	@DeleteMapping("/room/hostelId/roomId")
	public void deleteRoomById(@RequestParam String hostelId, @RequestParam int roomId) {
		System.out.print(hostelId);
		System.out.print(roomId);
		this.roomService.deleteRoom(hostelId, roomId);
	}
}
