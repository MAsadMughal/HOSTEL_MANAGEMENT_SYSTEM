package com.SpringBootProject.SpringBootProject.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.SpringBootProject.SpringBootProject.model.Room;
import com.SpringBootProject.SpringBootProject.model.RoomPrimaryKey;

public interface RoomDao extends JpaRepository<Room, RoomPrimaryKey> {
	List<Room> findByhostelId(String hostelId);
	Room findByhostelIdAndRoomId(String hostelId, int roomId);
	boolean existsByhostelIdAndRoomId(String hostelId, int roomId);
	void deleteByhostelIdAndRoomId(String hostelId, int roomId);
	List<Room> getByhostelIdAndRoomId(String hostelId,int roomId);
	
}
