package com.SpringBootProject.SpringBootProject.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "room")
@IdClass(RoomPrimaryKey.class)
public class Room {
	@Id
	private int roomId;
	@Id
	private String hostelId;
	private int roomCapacity;

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getRoomCapacity() {
		return roomCapacity;
	}

	public void setRoomCapacity(int roomCapacity) {
		this.roomCapacity = roomCapacity;
	}

	public String getHostelId() {
		return hostelId;
	}

	public void setHostelId(String hostelId) {
		this.hostelId = hostelId;
	}

	@Override
	public String toString() {
		return "RoomsController [roomId=" + roomId + ", roomCapacity=" + roomCapacity + ", hostelId=" + hostelId + "]";
	}

	public Room(int roomId, int roomCapacity, String hostelId) {
		super();
		this.roomId = roomId;
		this.roomCapacity = roomCapacity;
		this.hostelId = hostelId;
	}

	public Room() {
	}

}
