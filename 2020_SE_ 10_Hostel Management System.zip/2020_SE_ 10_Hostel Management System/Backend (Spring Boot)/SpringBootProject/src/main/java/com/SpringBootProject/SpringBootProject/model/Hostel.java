package com.SpringBootProject.SpringBootProject.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Hostel {
	@Id
	private String hostelId;
	private int noOfRooms;
	private int capacity;

	public String getHostelID() {
		return hostelId;
	}

	public void setHostelID(String hostelID) {
		this.hostelId = hostelID;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public Hostel() {
	}

	public Hostel(String hostelID, int noOfRooms, int capacity) {
		super();
		this.hostelId = hostelID;
		this.noOfRooms = noOfRooms;
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "Hostel [hostelID=" + hostelId + ", noOfRooms=" + noOfRooms + ", capacity=" + capacity + "]";
	}

}
