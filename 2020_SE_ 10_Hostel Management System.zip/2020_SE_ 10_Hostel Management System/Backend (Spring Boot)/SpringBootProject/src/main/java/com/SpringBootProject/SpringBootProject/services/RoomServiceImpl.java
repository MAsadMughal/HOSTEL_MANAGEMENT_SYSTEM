package com.SpringBootProject.SpringBootProject.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootProject.SpringBootProject.Dao.HostelDao;
import com.SpringBootProject.SpringBootProject.Dao.RoomDao;
import com.SpringBootProject.SpringBootProject.model.Hostel;
import com.SpringBootProject.SpringBootProject.model.Room;

import jakarta.transaction.Transactional;

@Service
public class RoomServiceImpl implements RoomService {
	@Autowired
	private RoomDao roomDao;
	@Autowired
	private HostelDao hostelDao;

	@Override
	public Room AddRoom(Room r) {

		boolean ex = roomDao.existsByhostelIdAndRoomId(r.getHostelId(), r.getRoomId());
		if (ex) {
			return null;
		} else { // TODO Auto-generated method stub
			Hostel h = hostelDao.findByhostelId(r.getHostelId());
			h.setCapacity(h.getCapacity() + r.getRoomCapacity());
			h.setNoOfRooms(h.getNoOfRooms() + 1);
			hostelDao.save(h);
			return roomDao.save(r);
		}
	}

	@Override
	public Room EditRoom(Room r) {
		boolean ex = roomDao.existsByhostelIdAndRoomId(r.getHostelId(), r.getRoomId());
		if (ex) {
			Room r1=roomDao.findByhostelIdAndRoomId(r.getHostelId(),r.getRoomId());
			
			Hostel h = hostelDao.findByhostelId(r.getHostelId());
			h.setCapacity(h.getCapacity() - r1.getRoomCapacity());
			h.setCapacity(h.getCapacity() + r.getRoomCapacity());
			hostelDao.save(h);
			return roomDao.save(r);
		} else {
			return null;
		}
	}

	@Override
	public List<Room> getRooms() {
		return roomDao.findAll();
	}

	@Override
	public List<Room> getRoomsByHostel(String hostelId) {
		return roomDao.findByhostelId(hostelId);
	}

	@Override
	@Transactional
	public void deleteRoom(String hostelId, int roomId) {
		boolean ex = roomDao.existsByhostelIdAndRoomId(hostelId, roomId);
		if (ex) {
			Room r = roomDao.findByhostelIdAndRoomId(hostelId, roomId);
			Hostel h = hostelDao.findByhostelId(r.getHostelId());
			h.setNoOfRooms(h.getNoOfRooms() - 1);
			h.setCapacity(h.getCapacity() - r.getRoomCapacity());
			hostelDao.save(h);
			roomDao.deleteByhostelIdAndRoomId(hostelId, roomId);
		}
	}

	@Override
	public Room findByhostelIdAndRoomId(String hostelId, int roomId) {
		return roomDao.findByhostelIdAndRoomId(hostelId, roomId);
	}

	@Override
	public List<Room> getByhostelIdAndRoomId(String hostelId, int roomId) {
		return roomDao.getByhostelIdAndRoomId(hostelId, roomId);
	}
}
