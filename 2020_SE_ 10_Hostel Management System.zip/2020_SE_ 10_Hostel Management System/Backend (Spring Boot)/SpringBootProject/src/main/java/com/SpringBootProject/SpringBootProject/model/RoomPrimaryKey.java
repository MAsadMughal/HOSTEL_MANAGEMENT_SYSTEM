package com.SpringBootProject.SpringBootProject.model;

import java.io.Serializable;


public class RoomPrimaryKey implements Serializable {
	private int roomId;
	private String hostelId;
}
