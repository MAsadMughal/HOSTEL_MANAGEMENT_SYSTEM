package com.SpringBootProject.SpringBootProject.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {
	@Id

	private String studentId;
	private String studentName;
	private String department;
	private String address;
	private String cellNo;
	private String hostelId;
	private int roomId;

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCellNo() {
		return cellNo;
	}

	public void setCellNo(String cellNo) {
		this.cellNo = cellNo;
	}

	public String getHostelId() {
		return hostelId;
	}

	public void setHostelId(String hostelId) {
		this.hostelId = hostelId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public Student() {
	}

	public Student(String studentId, String studentName, String department, String address, String cellNo,
			String hostelId, int roomId) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.department = department;
		this.address = address;
		this.cellNo = cellNo;
		this.hostelId = hostelId;
		this.roomId = roomId;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", department=" + department
				+ ", address=" + address + ", cellNo=" + cellNo + ", hostelId=" + hostelId + ", roomId=" + roomId + "]";
	}

}
