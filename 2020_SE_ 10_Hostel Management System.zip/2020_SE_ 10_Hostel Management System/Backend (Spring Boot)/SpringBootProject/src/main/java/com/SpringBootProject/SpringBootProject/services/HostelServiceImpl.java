package com.SpringBootProject.SpringBootProject.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootProject.SpringBootProject.Dao.HostelDao;
import com.SpringBootProject.SpringBootProject.model.Hostel;

@Service
public class HostelServiceImpl implements HostelService {
	@Autowired
	private HostelDao hostelDao;

	@Override
	public Hostel AddHostel(Hostel h) {
		boolean ex = hostelDao.existsById(h.getHostelID());
		if (ex) {
			return null;
		} else {
			hostelDao.save(h);
			return h;
		}
	}

	@Override
	public Hostel EditHostel(Hostel h) {
		hostelDao.save(h);
		return h;
	}

	@Override
	public List<Hostel> getHostel() {
		// TODO Auto-generated method stub
		return hostelDao.findAll();
	}

	@Override
	public Object findHostel(String id) {
		boolean ex = hostelDao.existsById(id);
		if (ex) {
			return hostelDao.findById(id);
		} else {
			return null;
		}
	}

	@Override
	public void deleteHostel(String HostelId) {
		boolean ex = hostelDao.existsById(HostelId);
		if (ex) {
			hostelDao.deleteById(HostelId);
		}
	}

}
