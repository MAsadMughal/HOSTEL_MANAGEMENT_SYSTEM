package com.SpringBootProject.SpringBootProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import com.SpringBootProject.SpringBootProject.model.Student;
import com.SpringBootProject.SpringBootProject.services.StudentService;

@RestController
@CrossOrigin
public class StudentsController {

	@Autowired
	private StudentService studentService;

	@PostMapping("/newStudent/id")
	public Student addStudent(@RequestBody Student student) {
		return this.studentService.addStudent(student);
	}

	@PutMapping("/editStudent")
	public Student editStudent(@RequestBody Student student) {
		return this.studentService.editStudent(student);
	}

	@GetMapping("/student")
	public List<Student> getStudent() {
		return this.studentService.getStudent();
	}

	@GetMapping("/student/id")
	public Object getStudentById(@RequestParam String id) {
		return this.studentService.getStudentById(id);
	}

	@DeleteMapping("/student/studentId")
	public void deleteStudent(@RequestParam String studentId) {
		this.studentService.deleteStudent(studentId);
	}

	@GetMapping("/students/Id")
	public List<Student> studentsByStudentId(@RequestParam String studentId) {
		// TODO Auto-generated method stub
		return this.studentService.getByStudentId(studentId);
	}

	@GetMapping("/students/hostelId")
	public List<Student> studentsByhostelId(@RequestParam String hostelId) {
		// TODO Auto-generated method stub
		return this.studentService.findByhostelId(hostelId);

	}

	@GetMapping("/students/hostelId/roomId")
	public List<Student> StudentsByhostelIdAndRoomId(@RequestParam String hostelId,@RequestParam int roomId) {
		return this.studentService.findByhostelIdAndRoomId(hostelId, roomId);

	}

}
