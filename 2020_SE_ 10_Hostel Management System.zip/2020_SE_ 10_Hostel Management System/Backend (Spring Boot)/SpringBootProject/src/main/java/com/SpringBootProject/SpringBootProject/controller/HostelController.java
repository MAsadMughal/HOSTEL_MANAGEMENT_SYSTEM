package com.SpringBootProject.SpringBootProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBootProject.SpringBootProject.model.Hostel;
import com.SpringBootProject.SpringBootProject.services.HostelService;

@CrossOrigin
@RestController
public class HostelController {

	@Autowired
	private HostelService hostelService;

	@PostMapping("/hostel")
	public Hostel addHostel(@RequestBody Hostel h) {
		return this.hostelService.AddHostel(h);
	}

	@GetMapping("/hostel")
	public List<Hostel> getHostel() {
		return this.hostelService.getHostel();
	}

	@GetMapping("/hostel/hostelId")
	public Object getHostelById(@RequestParam String hostelId) {
		return this.hostelService.findHostel(hostelId);
	}

	@PutMapping("/editHostel")
	public Hostel editHostel(@RequestBody Hostel h) {
		return this.hostelService.EditHostel(h);
	}

	@DeleteMapping("/hostel/Id")
	public void deleteHostel(@RequestParam String hostelId) {
		this.hostelService.deleteHostel(hostelId);
	}

}
