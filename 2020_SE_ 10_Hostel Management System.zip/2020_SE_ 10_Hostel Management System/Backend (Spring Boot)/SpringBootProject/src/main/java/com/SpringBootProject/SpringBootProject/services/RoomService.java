package com.SpringBootProject.SpringBootProject.services;

import java.util.List;

import com.SpringBootProject.SpringBootProject.model.Room;

public interface RoomService {
	public Room AddRoom(Room r);
	public Room EditRoom(Room r);
	public List<Room> getRooms();
	public List<Room> getRoomsByHostel(String hostelId);
	public void deleteRoom(String HostelId,int roomId) ;
	public Room findByhostelIdAndRoomId(String hostelId,int roomId);	
	public List<Room> getByhostelIdAndRoomId(String hostelId,int roomId);	

}
