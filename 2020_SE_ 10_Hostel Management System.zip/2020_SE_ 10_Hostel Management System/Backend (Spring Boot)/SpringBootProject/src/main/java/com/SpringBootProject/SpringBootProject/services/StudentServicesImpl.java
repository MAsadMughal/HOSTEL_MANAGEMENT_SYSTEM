package com.SpringBootProject.SpringBootProject.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootProject.SpringBootProject.Dao.HostelDao;
import com.SpringBootProject.SpringBootProject.Dao.RoomDao;
import com.SpringBootProject.SpringBootProject.Dao.StudentDao;
import com.SpringBootProject.SpringBootProject.model.Hostel;
import com.SpringBootProject.SpringBootProject.model.Room;
import com.SpringBootProject.SpringBootProject.model.Student;

@Service
public class StudentServicesImpl implements StudentService {

	@Autowired
	private StudentDao studentDao;
	@Autowired
	private RoomDao roomDao;
	@Autowired
	private HostelDao hostelDao;

	@Override
	public Student addStudent(Student stu) {
		boolean ex = studentDao.existsById(stu.getStudentId());
		Student stu1 = studentDao.findByStudentId(stu.getStudentId());
		System.out.print(ex);
		System.out.print(stu1);

		if (ex) {
			return null;
		} else {
			// Saving hostel and roomIDs
			String Hostelid = stu.getHostelId();
			int roomId = stu.getRoomId();

			// Finding hostel and Room
			Room room = roomDao.findByhostelIdAndRoomId(Hostelid, roomId);
			Hostel hostel = hostelDao.findByhostelId(Hostelid);

			// Setting Room And hostel Capacities
			if (room.getRoomCapacity() == 0 || hostel.getCapacity() == 0) {
				return null;

			} else {

				room.setRoomCapacity(room.getRoomCapacity() - 1);
				hostel.setCapacity(hostel.getCapacity() - 1);

				// Saving Capacities
				roomDao.save(room);
				hostelDao.save(hostel);
				studentDao.save(stu);
				return stu;
			}
		}
	}

	@Override
	public Student editStudent(Student stu) {
		boolean ex = studentDao.existsById(stu.getStudentId());
		System.out.print(stu);
		if (!ex) {
			return null;
		} else {
			Student s = studentDao.findByStudentId(stu.getStudentId());

			Hostel h = hostelDao.findByhostelId(s.getHostelId());
			Room r = roomDao.findByhostelIdAndRoomId(s.getHostelId(), s.getRoomId());
			h.setCapacity(h.getCapacity() + 1);
			r.setRoomCapacity(r.getRoomCapacity() + 1);
			hostelDao.save(h);
			roomDao.save(r);

			Hostel h1 = hostelDao.findByhostelId(stu.getHostelId());
			Room r1 = roomDao.findByhostelIdAndRoomId(stu.getHostelId(), stu.getRoomId());

			h1.setCapacity(h1.getCapacity() - 1);
			r1.setRoomCapacity(r1.getRoomCapacity() - 1);
			hostelDao.save(h1);
			roomDao.save(r1);
			
			
			studentDao.save(stu);
			return stu;
		}
	}

	@Override
	public List<Student> getStudent() {
		// TODO Auto-generated method stub
		return studentDao.findAll();
	}

	@Override
	public void deleteStudent(String studentId) {

		boolean ex = studentDao.existsById(studentId);
		if (!ex) {

		} else {
			Student stu = studentDao.findByStudentId(studentId);
			String Hostelid = stu.getHostelId();
			int roomId = stu.getRoomId();

			// Finding hostel and Room
			Room room = roomDao.findByhostelIdAndRoomId(Hostelid, roomId);
			Hostel hostel = hostelDao.findByhostelId(Hostelid);

			// Setting Room And hostel Capacities
			room.setRoomCapacity(room.getRoomCapacity() + 1);
			hostel.setCapacity(hostel.getCapacity() + 1);

			// Saving Capacities
			roomDao.save(room);
			hostelDao.save(hostel);

			studentDao.deleteById(studentId);
		}
	}

	@Override
	public Object getStudentById(String id) {
		// TODO Auto-generated method stub
		if (studentDao.existsById(id)) {
			return studentDao.findById(id);
		} else {
			return null;
		}
	}

	@Override
	public List<Student> getByStudentId(String studentId) {
		// TODO Auto-generated method stub
		if (studentDao.existsById(studentId)) {
			return studentDao.getByStudentId(studentId);
		} else {
			return null;
		}
	}

	@Override
	public List<Student> findByhostelId(String hostelId) {
		// TODO Auto-generated method stub
		return studentDao.findByhostelId(hostelId);

	}

	@Override
	public List<Student> findByhostelIdAndRoomId(String hostelId, int roomId) {
		if (studentDao.existsByhostelIdAndRoomId(hostelId, roomId)) {
			return studentDao.findByhostelIdAndRoomId(hostelId, roomId);
		} else {
			return null;
		}
	}

}
