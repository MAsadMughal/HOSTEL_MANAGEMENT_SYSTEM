package com.SpringBootProject.SpringBootProject.services;

import java.util.List;

import com.SpringBootProject.SpringBootProject.model.Hostel;

public interface HostelService {
	public Hostel AddHostel(Hostel h);
	public Hostel EditHostel(Hostel h);
	public List<Hostel> getHostel();
	public Object findHostel(String id);
	public void deleteHostel(String HostelId) ;
	}
