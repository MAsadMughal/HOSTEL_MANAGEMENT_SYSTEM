package com.SpringBootProject.SpringBootProject.services;

import java.util.List;

import com.SpringBootProject.SpringBootProject.model.Student;

public interface StudentService {
	public Student addStudent(Student stu);
	public Student editStudent(Student stu);
	public List<Student> getStudent();
	public Object getStudentById(String id);
	public void deleteStudent(String studentId);
	public List<Student> getByStudentId(String studentId);
	public List<Student> findByhostelId(String hostelId);
	public List<Student> findByhostelIdAndRoomId(String hostelId, int roomId);

}
