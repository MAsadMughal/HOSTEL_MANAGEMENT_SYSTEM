import { Button } from '@mui/material';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import axios from 'axios';
import * as React from 'react';
import { useEffect } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { getHostels } from '../../actions/HostelActions';
import Loader from '../Loader/Loader';
import Notification from '../Notifications/Notifications';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(() => ({
    '&:nth-of-type(odd)': {

    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));




export default function ShowHostels() {

    const dispatch = useDispatch();
    const Navigate = useNavigate();


    useEffect(() => {
        dispatch(getHostels());
    }, [])

    const deleteHostel = async (e) => {
        let id = e.currentTarget.id;
        console.log(id);
        let ask = false;
        ask = window.confirm('Are you sure you want to delete?');
        try {
            if (ask && id) {
                await axios.delete(`/hostel/Id?hostelId=${id}`);
                dispatch(getHostels());
                Notification("Success", `Deleted Hostel with ID :  ${id} Sucessfully.`, "success");
            } else if (!ask) {
                Notification("Cancelled", "Deletion Cancelled.", "warning");
            }
        } catch (error) {
            Notification("Error Deleting Room.", error.message, "danger");
        }
    }

    let { hostels, loading } = useSelector(state => state.hostels);
    return (<>
        {loading ? <Loader /> :
            <center>

                <TableContainer component={Paper} style={{ width: "95%" }} >
                    <ReactNotifications />
                    <center style={{ background: "transparent", padding: "10px" }}>
                        <Link to="/NewHostel" style={{ textDecoration: "none" }}>
                            <Button variant="contained" component="label">
                                Create a New Hostel
                            </Button>
                        </Link>
                    </center>
                    <Table sx={{ minWidth: 700 }} aria-label="customized table" style={{ marginBottom: "20px" }}>
                        <TableHead>
                            <TableRow >
                                <StyledTableCell align="center"><b>Hostel Name</b></StyledTableCell>
                                <StyledTableCell align="center"><b>No Of Rooms</b></StyledTableCell>
                                <StyledTableCell align="center"><b>Capacity</b></StyledTableCell>
                                <StyledTableCell align="center"><b>EDIT</b></StyledTableCell>
                                <StyledTableCell align="center"><b>DELETE</b></StyledTableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {hostels && hostels.map((row, key) => (
                                <StyledTableRow key={row.hostelID} id={row.hostelID} style={key % 2 !== 1 ? { backgroundColor: "lightgoldenrodyellow" } : { backgroundColor: "lightcyan" }}>
                                    <StyledTableCell align="center" scope='row' component="th" >{row.hostelID}</StyledTableCell>
                                    <StyledTableCell align="center" scope='row' >{row.noOfRooms}</StyledTableCell>
                                    <StyledTableCell align="center" scope='row'>{row.capacity}  </StyledTableCell>
                                    <StyledTableCell align="center" onClick={() => { Navigate(`/hostel/${row.hostelID}`) }} style={{ "cursor": "pointer", color: "blue" }} ><b>Edit</b></StyledTableCell>
                                    <StyledTableCell id={[row.hostelID]} align="center" onClick={deleteHostel} style={{ "cursor": "pointer", color: "red" }} ><b>Delete</b></StyledTableCell>
                                </StyledTableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>

            </center>
        }</>
    );
}