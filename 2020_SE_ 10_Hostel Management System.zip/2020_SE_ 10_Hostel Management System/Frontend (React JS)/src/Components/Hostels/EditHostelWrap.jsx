import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getHostelDetails } from '../../actions/HostelActions';
import Loader from '../Loader/Loader';
import EditHostels from './EditHostels';

const EditHostelWrap = () => {
    const newHostel = useSelector(state => state.newHostel);
    // const { hostelDetails, loading, error } = useSelector(state => state.HostelDetails);
    const { hostelDetails, loading, error } = useSelector(state => state.hostelDetails);
    const dispatch = useDispatch();
    const params = useParams();

    useEffect(() => {
        dispatch(getHostelDetails(params.hostelId));
    }, [])

    return (
        <div>
            {loading ? <Loader /> : <EditHostels hostelDetails={hostelDetails} /> }
        </div>
    )

}

export default EditHostelWrap
