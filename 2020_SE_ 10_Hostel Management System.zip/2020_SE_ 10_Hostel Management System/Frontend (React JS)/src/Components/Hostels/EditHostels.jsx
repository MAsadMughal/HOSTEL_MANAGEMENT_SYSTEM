import { Box, Button, Typography } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import { alpha, styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import React, { useEffect, useState } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { editYourHostel, refreshHostel } from '../../actions/HostelActions';
import { clearErrors } from '../../actions/StudentActions';
import Loader from '../Loader/Loader';
import Notification from '../Notifications/Notifications';

const RedditTextField = styled((props) => (
    <TextField InputProps={{ disableUnderline: true }} {...props} />
))(({ theme }) => ({
    '& .MuiFilledInput-root': {
        border: '1px solid #e2e2e1',
        overflow: 'hidden',
        borderRadius: 4,
        backgroundColor: theme.palette.mode === 'light' ? '#fcfcfb' : '#2b2b2b',
        transition: theme.transitions.create([
            'border-color',
            'background-color',
            'box-shadow',
        ]),
        '&:hover': {
            backgroundColor: 'transparent',
        },
        '&.Mui-focused': {
            backgroundColor: 'transparent',
            boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 2px`,
            borderColor: theme.palette.primary.main,
        },
    },
}));


let initialHostel = {
    hostelID: "",
    noOfRooms: 0,
    capacity: 0,
}

const EditHostels = ({ hostelDetails }) => {
    const dispatch = useDispatch();

    let [hostel, setHostel] = useState(initialHostel);
    const { newHostel, loading, error } = useSelector(state => state.newHostel);
   
    useEffect(() => {
        if (!loading && error) {
            Notification("Error", error, "danger");
            dispatch(clearErrors());
        } else if (!loading && Object.values(newHostel).length >= 1) {
            Notification("Success", "Hostel Updated Successfully.", "success");
            dispatch(refreshHostel());
        } else if (!loading && newHostel === "") {
            Notification("Error", "Error Updating Hostel.", "danger");
       
        }
    }, [loading, error])


    const gettingDetails = () => {
        setHostel(hostelDetails);
    }

    useEffect(() => {
        gettingDetails();
    }, [])


    const setForm = (e) => {
        setHostel((prevValue) => ({
            ...prevValue,
            [e.target.name]: e.target.value
        }))
    }

    function containsSpecialChars(str) {
        const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        return specialChars.test(str);
    }


    const editHostel = async () => {
        const { hostelID, capacity, noOfRooms } = hostel;

        if (!hostelID || !capacity || !noOfRooms) {
            Notification("Error", "Kindly fill all the fields.", "danger");
        } else if (/\d/.test(hostelID) || containsSpecialChars(hostelID)) {
            Notification("Error", "Hostel ID cannot contain Numbers or Special Characters.", "danger");
        }
        else if (hostelID.length >= 11) {
            Notification("Error", "Hostel ID cannot be greater than 10 Characters.", "danger");
        }
        else if (Number(noOfRooms) <= 9) {
            Notification("Error", "Rooms cannot be less than 10.", "danger");
        }
        else if ((capacity >= noOfRooms * 6)) {
            Notification("Error", "Capacity is too much for the available Rooms.", "danger");
        }
        else if ((capacity <= noOfRooms - 1)) {
            Notification("Error", "Capacity is less than available Rooms.", "danger");
        } else {
            dispatch(editYourHostel(hostel));
        }
    }



    return (
        <div>
            {loading ? <Loader /> :
                <div className='AddStudent'>
                    <ReactNotifications />
                    <Typography variant="h4" mt={4} component="h6">
                        EDIT HOSTEL DETAILS
                    </Typography>

                    <Box sx={{
                        width: 500,
                        maxWidth: '100%',
                    }}>
                        <FormControl variant="standard">
                        </FormControl>
                        <RedditTextField
                            label="Hostel Name"
                            name="hostelID"
                            disabled={true}
                            onChange={setForm}
                            value={hostel.hostelID}
                            id="Name-input"
                            variant="filled"
                            style={{ marginTop: 11 }}
                            fullWidth />
                    </Box>

                    <Box sx={{
                        width: 500,
                        maxWidth: '100%',
                    }}>
                        <FormControl variant="standard">
                        </FormControl>
                        <RedditTextField
                            type="number"
                            label="No of Rooms"
                            name="noOfRooms"
                            value={hostel.noOfRooms}
                            onChange={setForm}
                            id="Name-input"
                            variant="filled"
                            style={{ marginTop: 11 }}
                            fullWidth />
                    </Box>

                    <Box sx={{
                        width: 500,
                        maxWidth: '100%',
                    }}>
                        <FormControl variant="standard">
                        </FormControl>
                        <RedditTextField
                            type="number"
                            label={(hostel.noOfRooms && hostel.capacity > hostel.noOfRooms * 5) ? "Capacity too much." : "Capacity (Usually No of Rooms * 4)"}
                            name="capacity"
                            style={(hostel.noOfRooms && hostel.capacity > hostel.noOfRooms * 5) ? { marginTop: 11, border: "1px solid red" } : { marginTop: 11 }}
                            value={hostel.capacity}
                            onChange={setForm}
                            id="Name-input"
                            variant="filled"

                            fullWidth
                        />
                    </Box>
                    <Button variant="contained" className='mt mt-4' component="label" onClick={editHostel}>
                        Update Hostel Details
                    </Button>

                </div>
            }
        </div>
    )
}

export default EditHostels
