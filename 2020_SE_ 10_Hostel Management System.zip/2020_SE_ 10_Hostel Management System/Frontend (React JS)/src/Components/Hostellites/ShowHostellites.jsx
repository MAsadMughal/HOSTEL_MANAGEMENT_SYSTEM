import { Button, FormControl, InputLabel, MenuItem, Select, Typography } from '@mui/material';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import axios from 'axios';
import * as React from 'react';
import { useState } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { getRooms } from '../../actions/RoomActions';
import { getStudents } from '../../actions/StudentActions';
import Loader from '../Loader/Loader';
import Notification from '../Notifications/Notifications';
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(() => ({
    '&:nth-of-type(odd)': {

    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));


export default function ShowHostellites() {

    const dispatch = useDispatch();
    const Navigate = useNavigate();
    let [sbystu, setSbyStu] = React.useState(false);
    let [sbyR, setSbyR] = useState(false);
    let { students, loading } = useSelector(state => state.students);
    let { hostels } = useSelector(state => state.hostels);
    let { rooms } = useSelector(state => state.rooms);
    let [student, setStuId] = React.useState("");
    let [hostel, setHostel] = React.useState({ hostel: "", room: "" });

    const deleteStudent = async (e) => {
        let id = e.currentTarget.id;
        let ask = false;
        ask = window.confirm('Are you sure you want to delete?');
        try {
            if (ask && id) {
                await axios.delete(`/student/studentId?studentId=${id}`);
                Notification("Success", `Deleted Student with ID :  ${id} Sucessfully.`, "success");
                dispatch(getStudents());
            } else if (!ask) {
                Notification("Cancelled", "Deletion Cancelled.", "warning");
            }
        } catch (error) {
            Notification("Error Deleting Student.", error.message, "danger");
        }
    }

    const searchById = (e) => {
        setStuId(e.target.value);
        dispatch(getStudents(e.target.value));
    }

    const searchRoom = (e) => {
        setHostel((prevValue) => ({
            ...prevValue,
            hostel: e.target.value && e.target.value
        }))
        dispatch(getRooms(e.target.value));

    }

    const setRoomNo = (e) => {
        setHostel((prevValue) => ({
            ...prevValue,
            room: e.target.value && e.target.value
        }))
    }

    const searchByRoom = () => {
        dispatch(getStudents(undefined, hostel.hostel, hostel.room));
    }

    const searchByHostel = () => {
        dispatch(getStudents(undefined, hostel.hostel));
    }

    return (<>
        {loading ? <Loader /> :
            <>
                <center style={{ padding: "20px" }}>
                    <ReactNotifications />
                    <Typography variant="h4" mt={4} component="h6">
                        HOSTELLITES LIST UET LAHORE
                    </Typography>
                    <Button onClick={() => { (setSbyStu(!sbystu)); setSbyR(false); }} variant="outlined" style={{ "marginLeft": "30px", marginTop: "10px" }}>Search by Student</Button>
                    <Button onClick={() => { (setSbyR(!sbyR)); setSbyStu(false); }} variant="outlined" style={{ "marginLeft": "30px", marginTop: "10px" }}>Search by Hostel</Button>
                    <br />
                    {sbystu &&
                        <FormControl variant="standard" sx={{ minWidth: 220, marginLeft: '10px' }}>
                            <InputLabel id="demo-simple-select-standard-label">Student ID</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                                label={student}
                                value={student}
                                style={{ marginTop: 10, }}
                                name="studentId"
                                onChange={searchById}
                            >
                                <MenuItem value={0}>
                                    All
                                </MenuItem>

                                {students && students.map((item, ind) => {
                                    return (<MenuItem key={ind} value={item.studentId}>{item.studentId}</MenuItem>)
                                })}</Select>


                        </FormControl>
                    }
                    {sbyR &&
                        <div style={{ padding: "20px" }}>
                            <>
                                <FormControl variant="standard" sx={{ minWidth: 220, marginLeft: "20px" }}>
                                    <InputLabel id="demo-simple-select-standard-label">Hostel</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-standard-label"
                                        id="demo-simple-select-standard"
                                        value={hostel.hostel}
                                        style={{ marginTop: 10, }}
                                        onChange={searchRoom}
                                        name="hostelId"
                                        label="Hostel"
                                    >
                                        <MenuItem value={0}>
                                            <em>All</em>
                                        </MenuItem>
                                        {hostels && hostels.map((item, ind) => {
                                            return (
                                                <MenuItem key={ind} value={item.hostelID}>{item.hostelID}</MenuItem>
                                            )
                                        })}
                                    </Select>
                                </FormControl>
                                <Button onClick={searchByHostel} variant="outlined" style={{ "marginLeft": "30px", marginTop: "10px" }}>Search by Hostel</Button>

                            </>
                            {/* RoomNo */}
                            <br />
                            <>
                                <FormControl variant="standard" sx={{ minWidth: 220, marginLeft: '20px' }}>
                                    <InputLabel id="demo-simple-select-standard-label">Room No.</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-standard-label"
                                        id="demo-simple-select-standard"
                                        value={hostel.room} style={{ marginTop: 10, }}
                                        name="roomId"
                                        disabled={(hostel.hostel && rooms.length >= 1) ? false : true}
                                        onChange={setRoomNo}
                                        label="Room No"
                                    >
                                        <MenuItem value={0}>
                                        </MenuItem>

                                        {rooms && rooms.map((item, ind) => {
                                            return (<MenuItem key={ind} value={item.roomId}>{item.roomId}</MenuItem>)
                                        })}</Select>
                                </FormControl>
                                <Button onClick={searchByRoom} variant="outlined" style={{ "marginLeft": "30px", marginTop: "10px" }}>Search by Hostel & Room</Button>
                            </>
                        </div>}
                </center>
                <center>
                    <TableContainer component={Paper} style={{ width: "95%", marginBottom: "20%" }} >
                        <ReactNotifications />
                        <center style={{ background: "transparent", padding: "10px" }}>
                            <Link to="/NewStudent" style={{ textDecoration: "none" }}>
                                <Button variant="contained" component="label">
                                    Add a New Student
                                </Button>
                            </Link>
                        </center>
                        <Table sx={{ minWidth: 700 }} aria-label="customized table">
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell align="center"><b>Student ID</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Student Name</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Department</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Address</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Phone No.</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Hostel ID</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Room ID</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>EDIT</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>DELETE</b></StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {students && students.map((row, key) => (
                                    <StyledTableRow key={row.studentId} id={row.studentId} style={key % 2 !== 1 ? { backgroundColor: "lightgoldenrodyellow" } : { backgroundColor: "lightcyan" }}>
                                        <StyledTableCell align="center" scope='row' component="th" >{row.studentId}</StyledTableCell>
                                        <StyledTableCell align="center">{row.studentName}  </StyledTableCell>
                                        <StyledTableCell align="center">{row.department}</StyledTableCell>
                                        <StyledTableCell align="center">{row.address}</StyledTableCell>
                                        <StyledTableCell align="center">{row.cellNo}</StyledTableCell>
                                        <StyledTableCell align="center">{row.hostelId}</StyledTableCell>
                                        <StyledTableCell align="center">{row.roomId}</StyledTableCell>
                                        <StyledTableCell align="center" id={row.studentId} onClick={() => Navigate(`/student/${row.studentId}`)} style={{ "cursor": "pointer", color: "blue" }}><b>Edit</b></StyledTableCell>
                                        <StyledTableCell id={row.studentId} onClick={deleteStudent} style={{ "cursor": "pointer", color: "red" }} align="center"><b>Delete</b></StyledTableCell>
                                    </StyledTableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer></center>
            </>}</>
    );
}