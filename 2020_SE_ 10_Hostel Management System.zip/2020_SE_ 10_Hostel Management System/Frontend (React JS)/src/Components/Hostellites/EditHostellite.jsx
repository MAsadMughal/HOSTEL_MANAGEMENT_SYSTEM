import { Box, Button, Typography } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import { alpha, styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import React, { useEffect, useState } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { getRooms } from '../../actions/RoomActions';
import { clearErrors, editStudent, refreshStudent } from '../../actions/StudentActions';
import Notification from '../Notifications/Notifications';
import "./Hostellites.css";

const RedditTextField = styled((props) => (
    <TextField InputProps={{ disableUnderline: true }} {...props} />
))(({ theme }) => ({
    '& .MuiFilledInput-root': {
        border: '1px solid #e2e2e1',
        overflow: 'hidden',
        borderRadius: 4,
        backgroundColor: theme.palette.mode === 'light' ? '#fcfcfb' : '#2b2b2b',
        transition: theme.transitions.create([
            'border-color',
            'background-color',
            'box-shadow',
        ]),
        '&:hover': {
            backgroundColor: 'transparent',
        },
        '&.Mui-focused': {
            backgroundColor: 'transparent',
            boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 2px`,
            borderColor: theme.palette.primary.main,
        },
    },
}));


let initialStudent = {
    studentId: "",
    studentName: "",
    department: "",
    address: "",
    cellNo: "",
    hostelId: "",
    roomId: ""
}

export default function EditHostellite({ studentDetails }) {
    const dispatch = useDispatch();

    const { newStudent, loading, newError } = useSelector(state => state.newStudent);
    const { hostels } = useSelector(state => state.hostels);
    const { rooms } = useSelector(state => state.rooms);
    let [student, setStudent] = useState(initialStudent);
    const Navigate = useNavigate();

    const gettingDetails = () => {
        setStudent(studentDetails);
    }

    useEffect(() => {
        gettingDetails();
    }, [])

    console.log(newStudent);
    useEffect(() => {
        if (!loading && newError) {
            Notification("Error", newError, "success");
            dispatch(clearErrors());
        }
        else if (!loading && Object.values(newStudent).length >= 1) {
            dispatch(refreshStudent());
            Notification("Success", "Updated Successfully.", "success");
        } else if (!loading && newStudent === "") {
            dispatch(refreshStudent());
            Notification("Error", "Error Updating Student Details.", "danger");

        }
    }, [newError, loading])



    const setForm = (e) => {
        if (e.target.name === "hostelId") {
            dispatch(getRooms(e.target.value));
            setStudent((prevValue) => ({
                ...prevValue,
                roomId: ""
            }))
        }
        setStudent((prevValue) => ({
            ...prevValue,
            [e.target.name]: e.target.value
        }))
    }

    const UpdateHostellite = async () => {
        const { studentId, studentName, department, address, cellNo, hostelId, roomId } = student;
        if (studentId && studentName && department && address && cellNo.length >= 10 && cellNo.length <= 13 && hostelId && roomId) {
            dispatch(editStudent(student));
        } else {
            Notification("Error", "Enter all Required Fields. Phone should be at 10 to 13 characters long.", "danger");
        }
    }





    return (
        <>
            <center>
                <>
                    <ReactNotifications />
                    <Typography variant="h4" mt={4} component="h6">
                        EDIT HOSTELLITE DETAILS
                    </Typography>

                    <div className='AddStudent'>
                        <Box sx={{
                            width: 500,
                            maxWidth: '100%',
                        }}>
                            <FormControl variant="standard">
                            </FormControl>
                            <RedditTextField
                                value={student.studentId && student.studentId}
                                disabled={true}
                                label="Student ID"
                                name="studentId"
                                onChange={setForm}
                                id="Name-input"
                                variant="filled"
                                style={{ marginTop: 11 }}
                                fullWidth />
                        </Box>

                        <Box sx={{
                            width: 500,
                            maxWidth: '100%',
                        }}>
                            <FormControl variant="standard">
                            </FormControl>
                            <RedditTextField
                                label="Name"
                                name="studentName"
                                value={student.studentName && student.studentName}
                                onChange={setForm}
                                id="Name-input"
                                variant="filled"
                                style={{ marginTop: 11 }}

                                fullWidth />
                        </Box>

                        <Box sx={{
                            width: 500,
                            maxWidth: '100%',
                        }}>
                            <FormControl variant="standard">
                            </FormControl>
                            <RedditTextField
                                label="Dept."
                                name="department"
                                value={student.department && student.department}
                                onChange={setForm}
                                id="Name-input"
                                variant="filled"
                                style={{ marginTop: 11 }}
                                fullWidth />
                        </Box>

                        <Box sx={{
                            width: 500,
                            maxWidth: '100%',
                        }}>
                            <FormControl variant="standard">
                            </FormControl>
                            <RedditTextField
                                label="Address"
                                name="address"
                                value={student.address && student.address}
                                onChange={setForm}
                                id="Name-input"
                                variant="filled"
                                style={{ marginTop: 11 }}
                                fullWidth
                            />
                        </Box>

                        <Box sx={{
                            width: 500,
                            maxWidth: '100%',
                        }}>
                            <FormControl variant="standard">
                            </FormControl>
                            <RedditTextField
                                type="number"
                                label="Phone Number"
                                name="cellNo"
                                value={student.cellNo && student.cellNo}
                                onChange={setForm}
                                id="Name-input"
                                variant="filled"
                                style={{ marginTop: 11 }}
                                fullWidth
                            />
                        </Box>

                        {/* Hostel Number */}
                        <FormControl variant="standard" sx={{ minWidth: 220 }}>
                            <InputLabel id="demo-simple-select-standard-label">Hostel</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                                value={student.hostelId && student.hostelId} style={{ marginTop: 11 }}
                                onChange={setForm}
                                name="hostelId"
                                label="Hostel"
                            >
                                {hostels && hostels.map((item, ind) => {
                                    return (
                                        <MenuItem key={ind} value={item.hostelID && item.hostelID}>{item.hostelID}</MenuItem>
                                    )
                                })}
                            </Select>
                        </FormControl>


                        {/* RoomNo */}
                        <FormControl variant="standard" sx={{ minWidth: 220 }}>
                            <InputLabel id="demo-simple-select-standard-label">Room No.</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                                value={student.roomId && student.roomId} style={{ marginTop: 11 }}
                                name="roomId"
                                onChange={setForm}
                                label="Room No"
                            >

                                {rooms && rooms.map((item, ind) => {
                                    return (<MenuItem key={ind} value={item.roomId}>{item.roomId}</MenuItem>)
                                })}</Select>
                        </FormControl>
                    </div>
                    <Button variant="contained" component="label" onClick={UpdateHostellite}>
                        Update Details
                    </Button>
                </>
            </center >
        </>
    );
}