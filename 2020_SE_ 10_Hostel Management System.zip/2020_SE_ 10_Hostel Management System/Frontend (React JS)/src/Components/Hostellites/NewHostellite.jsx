import React, { useEffect, useState } from 'react';
import { alpha, styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import { Box } from '@mui/material';
import "./Hostellites.css";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import { Typography, Button } from '@mui/material';
import Notification from '../Notifications/Notifications';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { getRooms } from '../../actions/RoomActions';
import { addStudent, clearErrors, refreshStudent } from '../../actions/StudentActions';

const RedditTextField = styled((props) => (
  <TextField InputProps={{ disableUnderline: true }} {...props} />
))(({ theme }) => ({
  '& .MuiFilledInput-root': {
    border: '1px solid #e2e2e1',
    overflow: 'hidden',
    borderRadius: 4,
    backgroundColor: theme.palette.mode === 'light' ? '#fcfcfb' : '#2b2b2b',
    transition: theme.transitions.create([
      'border-color',
      'background-color',
      'box-shadow',
    ]),
    '&:hover': {
      backgroundColor: 'transparent',
    },
    '&.Mui-focused': {
      backgroundColor: 'transparent',
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 2px`,
      borderColor: theme.palette.primary.main,
    },
  },
}));


let initialStudent = {
  studentId: "",
  studentName: "",
  department: "",
  address: "",
  cellNo: "",
  hostelId: "",
  roomId: ""
}


export default function NewHostellite() {
  const dispatch = useDispatch();

  let [student, setStudent] = useState(initialStudent);
  const { newStudent, loading, error } = useSelector(state => state.newStudent);
  const { hostels } = useSelector(state => state.hostels);
  const { rooms } = useSelector(state => state.rooms);

  useEffect(() => {
    if (!loading && error) {
      Notification("Error", error, "danger");
      dispatch(clearErrors());
    } else if (!loading && Object.values(newStudent).length >= 1) {
      Notification("Success", "Room alloted Successfully", "success");
      dispatch(refreshStudent());
      setStudent(initialStudent);
    } else if (!loading && newStudent === "") {
      Notification("Error", "Student ID or Room Capacity Error.", "danger");
      dispatch(refreshStudent());
      setStudent(initialStudent);
    }

  }, [loading, error])



  const setForm = (e) => {
    if (e.target.name === "hostelId") {
      setStudent((prevValue) => ({
        ...prevValue,
        roomId: ""
      }))
      dispatch(getRooms(e.target.value));
    }
    setStudent((prevValue) => ({
      ...prevValue,
      [e.target.name]: e.target.value
    }))
  }

  const allotNewRoom = async () => {
    const { studentId, studentName, department, address, cellNo, hostelId, roomId } = student;
    if (studentId && studentName && department && address && cellNo.length >= 10 && cellNo.length <= 13 && hostelId && roomId) {
      dispatch(addStudent(student));
    } else {
      Notification("Error", "Enter all Required Fields. Phone should be at 10 to 13 characters long.", "danger");
    }

  }





  return (

    <center >
      <ReactNotifications />
      <Typography variant="h4" mt={4} component="h6">
        Allot Room to Student
      </Typography>

      <div className='AddStudent'>
        <Box sx={{
          width: 500,
          maxWidth: '100%',
        }}>
          <FormControl variant="standard">
          </FormControl>
          <RedditTextField
            label="Student ID"
            name="studentId"
            onChange={setForm}
            value={student.studentId}
            id="Name-input"
            variant="filled"
            style={{ marginTop: 11 }}
            fullWidth />
        </Box>

        <Box sx={{
          width: 500,
          maxWidth: '100%',
        }}>
          <FormControl variant="standard">
          </FormControl>
          <RedditTextField
            label="Name"
            name="studentName"
            value={student.studentName}
            onChange={setForm}
            id="Name-input"
            variant="filled"
            style={{ marginTop: 11 }}

            fullWidth />
        </Box>

        <Box sx={{
          width: 500,
          maxWidth: '100%',
        }}>
          <FormControl variant="standard">
          </FormControl>
          <RedditTextField
            label="Dept."
            name="department"
            value={student.department}
            onChange={setForm}
            id="Name-input"
            variant="filled"
            style={{ marginTop: 11 }}
            fullWidth />
        </Box>

        <Box sx={{
          width: 500,
          maxWidth: '100%',
        }}>
          <FormControl variant="standard">
          </FormControl>
          <RedditTextField
            label="Address"
            name="address"
            value={student.address}
            onChange={setForm}
            id="Name-input"
            variant="filled"
            style={{ marginTop: 11 }}
            fullWidth
          />
        </Box>

        <Box sx={{
          width: 500,
          maxWidth: '100%',
        }}>
          <FormControl variant="standard">
          </FormControl>
          <RedditTextField
            type="number"
            label="Phone Number"
            name="cellNo"
            value={student.cellNo}
            onChange={setForm}
            id="Name-input"
            variant="filled"
            style={{ marginTop: 11 }}
            fullWidth
          />
        </Box>

        {/* Hostel Number */}
        <div style={{ display: "flex", "justifyContent": "space-evenly", "alignItems": "center", padding: "50px", }}>

          <FormControl variant="standard" sx={{ minWidth: 220, }}>
            <InputLabel id="demo-simple-select-standard-label">Hostel</InputLabel>
            <Select
              labelId="demo-simple-select-standard-label"
              id="demo-simple-select-standard"
              value={student.hostelId}
              style={{ marginTop: 10, marginRight: '10px' }}
              onChange={setForm}
              name="hostelId"
              label="Hostel"
            >
              <MenuItem value={''}>
                <em>None</em>
              </MenuItem>
              {hostels && hostels.map((item, ind) => {
                return (
                  <MenuItem key={ind} value={item.hostelID}>{item.hostelID}</MenuItem>
                )
              })}
            </Select>
          </FormControl>


          {/* RoomNo */}
          <FormControl variant="standard" sx={{ minWidth: 220, marginLeft: '10px' }}>
            <InputLabel id="demo-simple-select-standard-label">Room No.</InputLabel>
            <Select
              labelId="demo-simple-select-standard-label"
              id="demo-simple-select-standard"
              value={student.roomId} style={{ marginTop: 10, }}
              name="roomId"
              disabled={(student.hostelId || (rooms && rooms.length >= 1)) ? false : true}
              onChange={setForm}
              label="Room No"
            >
              <MenuItem value={0}>
              </MenuItem>

              {rooms && rooms.map((item, ind) => {
                return (<MenuItem key={ind} value={item.roomId}>{item.roomId}</MenuItem>)
              })}</Select>
          </FormControl>
        </div>
        <Button variant="contained" component="label" onClick={allotNewRoom}>
          Allot a Room
        </Button>
      </div>
    </center >

  );
}