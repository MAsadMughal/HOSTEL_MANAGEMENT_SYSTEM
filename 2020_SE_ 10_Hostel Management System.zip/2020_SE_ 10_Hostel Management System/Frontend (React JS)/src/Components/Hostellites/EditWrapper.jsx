import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getStudentDetails } from '../../actions/StudentActions';
import Loader from '../Loader/Loader';
import EditHostellite from './EditHostellite';

const EditWrapper = () => {
    const { studentDetails, loading } = useSelector(state => state.studentDetails);
    const dispatch = useDispatch();
    const params = useParams();
    useEffect(() => {
        dispatch(getStudentDetails(params.id));
    }, [])

    return (
        <div>
            {loading ? <Loader /> : (Object.values(studentDetails).length >= 6) ? <EditHostellite studentDetails={studentDetails} /> : null}
        </div>
    )
}

export default EditWrapper
