import { ApartmentOutlined, HomeOutlined, Logout, NightShelterOutlined, SchoolOutlined } from '@mui/icons-material';
import { Tooltip } from '@mui/material';
import Box from '@mui/material/Box';
import SpeedDial from '@mui/material/SpeedDial';
import SpeedDialAction from '@mui/material/SpeedDialAction';
import SpeedDialIcon from '@mui/material/SpeedDialIcon';
import { styled } from '@mui/material/styles';
import * as React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { logoutAdmin } from '../../actions/AuthActions';
import { getStudents } from '../../actions/StudentActions';
import store from '../../store';

const StyledSpeedDial = styled(SpeedDial)(({ theme }) => ({
    position: 'absolute',
    '&.MuiSpeedDial-directionUp, &.MuiSpeedDial-directionLeft': {
        bottom: theme.spacing(2),
        right: theme.spacing(2),
    },
    '&.MuiSpeedDial-directionDown, &.MuiSpeedDial-directionRight': {
        top: theme.spacing(2),
        left: theme.spacing(2),
    },
}));

const actions = [
    { icon: <HomeOutlined />, name: 'HomePage' },
    { icon: <SchoolOutlined />, name: 'Students' },
    { icon: <NightShelterOutlined />, name: 'Rooms' },
    { icon: <ApartmentOutlined />, name: 'Hostels' },
    { icon: <Logout />, name: 'LOGOUT' },
];

export default function MenuBox() {
    const Navigate = useNavigate();
    const iconsAction = (e) => {
        const act = e.currentTarget.ariaLabel;
        if (act === "LOGOUT") {
            let ask = false;
            ask = window.confirm('Are you sure you want to LOGOUT?');
            if (ask) {
                dispatch(logoutAdmin());
            } else if (!ask) {
                alert("Logout Cancelled..")
            }

        } else if (act === "HomePage") {
            Navigate("/");
        } else if (act === "Students") {
            store.dispatch(getStudents());
            Navigate(`/Students`);
        } else {
            Navigate(`/${act}`);
        }
    }
    const dispatch = useDispatch();
    const [hidden] = React.useState(false);
    return (
        <Box sx={{ position: 'relative', mt: 3, height: 320, }}>
            <Tooltip title="Menu Icon">
                <StyledSpeedDial
                    ariaLabel="SpeedDial playground example"
                    hidden={hidden}
                    icon={<SpeedDialIcon />}
                    direction={window.innerWidth >= 400 ? "left" : "up"}
                >
                    {actions.map((action) => (
                        <SpeedDialAction
                            key={action.name}
                            icon={action.icon}
                            id={action.name}
                            tooltipTitle={action.name}
                            onClick={iconsAction} />
                    ))}
                </StyledSpeedDial>
            </Tooltip>
        </Box>
    );
}