import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getRoomDetails } from '../../actions/RoomActions';
import Loader from '../Loader/Loader';
import EditRoom from './EditRoom';

const EditRoomWrap = () => {

    const { roomDetails, loading} = useSelector(state => state.roomDetails);
    const dispatch = useDispatch();
    const params = useParams();
    useEffect(() => {
        dispatch(getRoomDetails(params.hostelId, params.roomId, true));
    }, [])

    return (
        <div>
            {loading ? <Loader /> : <EditRoom roomDetails={roomDetails} />}
        </div>
    )
}

export default EditRoomWrap
