import { Box, Button, Typography } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import { alpha, styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import React, { useEffect, useState } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { editRoomDetails, refreshRoom } from '../../actions/RoomActions';
import { clearErrors } from '../../actions/StudentActions';
import Notification from '../Notifications/Notifications';
import "./Room.css";
const RedditTextField = styled((props) => (
    <TextField InputProps={{ disableUnderline: true }} {...props} />
))(({ theme }) => ({
    '& .MuiFilledInput-root': {
        border: '1px solid #e2e2e1',
        overflow: 'hidden',
        borderRadius: 4,
        backgroundColor: theme.palette.mode === 'light' ? '#fcfcfb' : '#2b2b2b',
        transition: theme.transitions.create([
            'border-color',
            'background-color',
            'box-shadow',
        ]),
        '&:hover': {
            backgroundColor: 'transparent',
        },
        '&.Mui-focused': {
            backgroundColor: 'transparent',
            boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 2px`,
            borderColor: theme.palette.primary.main,
        },
    },
}));

let initialRoom = {
    roomId: "",
    roomCapacity: "",
    hostelId: "",
}

const EditRoom = ({ roomDetails }) => {
    const dispatch = useDispatch();

    const { newRoom, loading, error } = useSelector(state => state.newRoom);
    let [room, setRoom] = useState(initialRoom);
    useEffect(() => {
        setRoom(roomDetails);
    }, [initialRoom])

    useEffect(() => {
        if (!loading && error) {
            Notification("Error", error, "danger");
            dispatch(clearErrors());
        } else if (!loading && Object.values(newRoom).length >= 1) {
            Notification("Success", "Details Updated Successfully", "success");
            dispatch(refreshRoom());
        } else if (!loading && newRoom === "") {
            Notification("Error", "Error Updating Details", "danger");
        }
    }, [loading, error])



    const setForm = (e) => {
        setRoom((prevValue) => ({
            ...prevValue,
            [e.target.name]: e.target.value
        }))
    }

    const editHostelRoom = async () => {
        const { roomCapacity } = room;
        if (!roomCapacity) {
            Notification("Error", "Kindly define the Room Capacity.", "danger");
        }
        else if ((roomCapacity >= 11 || roomCapacity <= 0)) {
            Notification("Error", "Capacity should be maximum 10 for a room.", "danger");
        } else {
            dispatch(editRoomDetails(room));
        }
    }




    return (
        <div>

            <ReactNotifications />
            <center>
                <Typography variant="h4" mt={4} component="h6">
                    EDIT ROOM
                </Typography>

                <div className='newRoom'>
                    <Box sx={{
                        width: 500,
                        maxWidth: '100%',
                    }}>
                        <FormControl variant="standard">
                        </FormControl>
                        <RedditTextField
                            label="Hostel"
                            name="hostelId"
                            disabled={true}
                            value={room.hostelId}
                            id="Name-input"
                            variant="filled"
                            style={{ marginTop: 11 }}
                            fullWidth />
                    </Box>


                    <Box sx={{
                        width: 500,
                        maxWidth: '100%',
                    }}>
                        <FormControl variant="standard">
                        </FormControl>
                        <RedditTextField
                            type="number"
                            label="Room No"
                            name="roomId"
                            disabled={true}
                            value={room.roomId}
                            id="Name-input"
                            variant="filled"
                            style={{ marginTop: 11 }}
                            fullWidth />
                    </Box>

                    <Box sx={{
                        width: 500,
                        maxWidth: '100%',
                    }}>
                        <FormControl variant="standard">
                        </FormControl>
                        <RedditTextField
                            type="number"
                            label={(room.roomCapacity && (room.roomCapacity >= 11 || room.roomCapacity <= 0)) ? "Capacity out of Range." : "Room Capacity (No of Students per room)*"}
                            name="roomCapacity"
                            style={(room.roomCapacity && (room.roomCapacity >= 11 || room.roomCapacity <= 0)) ? { marginTop: 11, border: "1px solid red" } : { marginTop: 11 }}
                            value={room.roomCapacity}
                            onChange={setForm}
                            id="Name-input"
                            variant="filled"

                            fullWidth
                        />
                    </Box>

                </div>
                <Button variant="contained" component="label" onClick={editHostelRoom}>
                    Update Room Details
                </Button>
            </center>

        </div>
    )
}

export default EditRoom
