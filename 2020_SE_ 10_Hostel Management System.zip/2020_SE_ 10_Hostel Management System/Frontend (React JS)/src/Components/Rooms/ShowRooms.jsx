import { Button, FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import axios from 'axios';
import * as React from 'react';
import { useEffect } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { clearErrors, getRooms } from '../../actions/RoomActions';
import Loader from '../Loader/Loader';
import Notification from '../Notifications/Notifications';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(() => ({
    '&:nth-of-type(odd)': {

    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));




export default function ShowRooms() {

    const dispatch = useDispatch();
    const Navigate = useNavigate();

    useEffect(() => {
        dispatch(getRooms());
    }, [])

    const { hostels } = useSelector(state => state.hostels);
    let [hostelId, setHostelId] = React.useState("");
    let [room, setRoom] = React.useState("");

    const changeHostel = (e) => {
        setHostelId(e.target.value);
        dispatch(getRooms(e.target.value));
    }

    const changeRoom = (e) => {
        setRoom(e.target.value);
        dispatch(getRooms(hostelId, e.target.value));
    }
    const deleteRoom = async (e) => {
        let id = e.currentTarget.id;
        id = id.split(',');
        console.log();
        let ask = false;
        ask = window.confirm('Are you sure you want to delete?');
        try {
            if (ask && id[0] && id[1]) {
                await axios.delete(`/room/hostelId/roomId?hostelId=${id[1]}&roomId=${id[0]}`);
                dispatch(getRooms());
                Notification("Success", `Deleted Room with ID :  ${id[0]} Sucessfully.`, "success");
            } else if (!ask) {
                Notification("Cancelled", "Deletion Cancelled.", "warning");
            }
        } catch (error) {
            Notification("Error Deleting Room.", error.message, "danger");
            clearErrors();
        }
    }

    let { rooms, loading } = useSelector(state => state.rooms);
    return (<>
        {loading ? <Loader /> :
            <>
                <center style={{ padding: "50px" }}>
                    <FormControl variant="standard" sx={{ minWidth: 220 }}>
                        <InputLabel id="demo-simple-select-standard-label">Hostel</InputLabel>
                        <Select
                            labelId="demo-simple-select-standard-label"
                            id="demo-simple-select-standard"
                            value={hostelId}
                            style={{ marginTop: 11 }}
                            onChange={changeHostel}
                            name="hostelId"
                            label="Hostel"
                        >
                            <MenuItem value={""}>
                                <em>All Hostels</em>
                            </MenuItem>
                            {hostels && hostels.map((item, ind) => {
                                return (
                                    <MenuItem key={ind} value={item.hostelID}>{item.hostelID}</MenuItem>
                                )
                            })}
                        </Select>
                    </FormControl>
                    <FormControl variant="standard" sx={{ minWidth: 220, marginLeft: '10px' }}>
                        <InputLabel id="demo-simple-select-standard-label">Room No.</InputLabel>
                        <Select
                            labelId="demo-simple-select-standard-label"
                            id="demo-simple-select-standard"
                            value={room} style={{ marginTop: 10, }}
                            name="roomId"
                            disabled={hostelId ? false : true}
                            onChange={changeRoom}
                            label="Room No"
                        >
                            <MenuItem value={0}>
                                <em>All Rooms</em>
                            </MenuItem>

                            {rooms && rooms.map((item, ind) => {
                                return (<MenuItem key={ind} value={item.roomId}>{item.roomId}</MenuItem>)
                            })}</Select>
                    </FormControl>


                    <TableContainer component={Paper} style={{ width: "95%", marginBottom: "20%",marginTop:"10%" }} >
                        <ReactNotifications />
                        <center style={{ background: "transparent", padding: "10px" }}>
                            <Link to="/NewRoom" style={{ textDecoration: "none" }}>
                                <Button variant="contained" component="label">
                                    Add a New Room
                                </Button>
                            </Link>
                        </center>
                        <Table sx={{ minWidth: 700 }} aria-label="customized table">
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell align="center"><b>Room ID</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Hostel Name</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>Capacity</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>EDIT</b></StyledTableCell>
                                    <StyledTableCell align="center"><b>DELETE</b></StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rooms && rooms.map((row, key) => (
                                    <StyledTableRow key={key} id={row.roomId} style={key % 2 !== 1 ? { backgroundColor: "lightgoldenrodyellow" } : { backgroundColor: "lightcyan" }}>
                                        <StyledTableCell align="center" scope='row' component="th" >{row.roomId}</StyledTableCell>
                                        <StyledTableCell align="center" scope='row' >{row.hostelId}</StyledTableCell>
                                        <StyledTableCell align="center" scope='row'>{row.roomCapacity}  </StyledTableCell>
                                        <StyledTableCell align="center" onClick={() => { Navigate(`/room/${row.hostelId}/${row.roomId}`) }} style={{ "cursor": "pointer", color: "blue" }} ><b>Edit</b></StyledTableCell>
                                        <StyledTableCell id={[row.roomId, row.hostelId]} align="center" onClick={deleteRoom} style={{ "cursor": "pointer", color: "red" }} ><b>Delete</b></StyledTableCell>
                                    </StyledTableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </center>

            </>
        }</>
    );
}