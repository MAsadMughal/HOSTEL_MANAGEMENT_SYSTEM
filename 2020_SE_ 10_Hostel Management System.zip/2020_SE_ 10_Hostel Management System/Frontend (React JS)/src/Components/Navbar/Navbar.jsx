import { MenuBook } from '@mui/icons-material';
import { Menu, Slider } from '@mui/material';
import AppBar from '@mui/material/AppBar';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import Toolbar from '@mui/material/Toolbar';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import 'bootstrap/dist/css/bootstrap.min.css';
import * as React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { loginAdmin, logoutAdmin } from '../../actions/AuthActions';
import image from "../../Images/image.png";
import logo from "../../Images/UETLOGO.png";
import MenuBox from '../SpeedDial/MenuBox';
import WidgetsIcon from '@mui/icons-material/Widgets';

export default function Navbar() {
    const Navigate = useNavigate();
    const { admin } = useSelector(state => state.admin);
    let [showMenu, setShow] = React.useState(true);

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar position="fixed" >
                <Toolbar>
                    <Box sx={{ flexGrow: 1 }}>

                        <Tooltip title={showMenu ? "HIDE MENU" : "SHOW MENU ICON"}>
                            <IconButton style={{ color: "white",marginRight:"5px" }} onClick={() => setShow(!showMenu)}>
                                <WidgetsIcon />
                            </IconButton>
                        </Tooltip>

                        <Tooltip title="UET LAHORE">
                            <IconButton sx={{ p: 0 }}>
                                <Avatar alt="Remy Sharp" src={logo} />
                            </IconButton>
                        </Tooltip>
                    </Box>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        UET HOSTELS
                    </Typography>




                    {admin.admin === process.env.REACT_APP_ADMIN ? <Box sx={{ flexGrow: 0 }}>
                        {(showMenu && admin.admin === process.env.REACT_APP_ADMIN) ? <div style={{ position: "fixed", right: "5%", bottom: "5%", zIndex: "1" }}>
                            <MenuBox />
                        </div> : null}
                        <Tooltip title="ASAD ULLAH">
                            <IconButton sx={{ p: 0 }}>
                                <Avatar alt="Remy Sharp" src={image} />
                            </IconButton>
                        </Tooltip>
                    </Box> : <button type="button" className="btn btn-info" onClick={() => Navigate("/login")}><b>LOGIN</b></button>}
                </Toolbar>
            </AppBar>
        </Box>
    );
}
