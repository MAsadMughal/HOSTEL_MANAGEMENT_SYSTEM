import { useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NewHostellite from "./Components/Hostellites/NewHostellite";
import Loader from "./Components/Loader/Loader";
import Navbar from "./Components/Navbar/Navbar";
// import Notification from "./Components/Notifications/Notifications";
import { ReactNotifications } from "react-notifications-component";
import { useSelector } from "react-redux";
import { getHostels } from "./actions/HostelActions";
import { getRooms } from "./actions/RoomActions";
import { getStudents } from "./actions/StudentActions";
import EditHostellite from "./Components/Hostellites/EditHostellite";
import ShowHostellites from "./Components/Hostellites/ShowHostellites";
import NewHostel from "./Components/Hostels/NewHostel";
import ShowHostels from "./Components/Hostels/ShowHostels";
import Login from "./Components/LOGIN/Login";
import NewRoom from "./Components/Rooms/NewRoom";
import ShowRooms from "./Components/Rooms/ShowRooms";
import MenuBox from "./Components/SpeedDial/MenuBox";
import store from "./store";
import EditWrapper from "./Components/Hostellites/EditWrapper";
import EditHostelWrap from "./Components/Hostels/EditHostelWrap";
import EditRoomWrap from "./Components/Rooms/EditRoomWrap";
function App() {
  //Error And Loading in requests
  let { loading } = useSelector(state => state.students);
  useEffect(() => {
    store.dispatch(getStudents());
    store.dispatch(getHostels());
    store.dispatch(getRooms());
  }, [])
  const { admin } = useSelector(state => state.admin);
  console.log(admin);
  const auth = admin.admin === process.env.REACT_APP_ADMIN;
  return (
    <BrowserRouter>
      <Navbar /><br /><br /><br />
      <ReactNotifications />

      {(loading) ? <Loader /> :
        <Routes>
          <Route exact path="/" element={auth ? <ShowHostellites /> : <Login />} />
          <Route exact path="/login" element={auth ? <ShowHostellites /> : <Login />} />
          <Route exact path="/hostels" element={auth ? <ShowHostels /> : <Login />} />
          <Route exact path="/rooms" element={auth ? <ShowRooms /> : <Login />} />
          <Route exact path="/students" element={auth ? <ShowHostellites /> : <Login />} />
          <Route exact path="/newHostel" element={auth ? <NewHostel /> : <Login />} />
          <Route exact path="/newStudent" element={auth ? <NewHostellite /> : <Login />} />
          <Route exact path="/newRoom" element={auth ? <NewRoom /> : <Login />} />
          <Route exact path={`/student/:id`} element={auth ? <EditWrapper /> : <Login />} />
          <Route exact path={`/hostel/:hostelId`} element={auth ? <EditHostelWrap /> : <Login />} />
          <Route exact path={`/room/:hostelId/:roomId`} element={auth ? <EditRoomWrap /> : <Login />} />
          <Route exact path={`*`} element={<DefaultPage />} />
        </Routes>
      }
    </BrowserRouter>

  );
}
export default App;
const DefaultPage = () => {
  return (
    <div>
      <center>
        <h1 style={{ marginTop: "20%" ,color:"blue"}}>
          OOPS!... WRONG PATH.. NO PAGE FOUND..
        </h1>
      </center>
    </div>
  )
}