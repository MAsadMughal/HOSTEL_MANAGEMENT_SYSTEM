import { createStore, combineReducers, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import { newStudentReducer, studentDetailsReducer, studentReducer } from "./reducers/StudentReducers";
import { hostelDetailsReducer, HostelReducer, newHostelReducer } from "./reducers/HostelReducers";
import { newRoomReducer, roomDetailsReducer, RoomReducer } from "./reducers/RoomReducers";
import { AuthReducer } from "./reducers/AuthReducers";


const reducer = combineReducers({
    students: studentReducer,
    hostels: HostelReducer,
    rooms: RoomReducer,
    newStudent: newStudentReducer,
    newRoom: newRoomReducer,
    newHostel: newHostelReducer,
    studentDetails: studentDetailsReducer,
    hostelDetails: hostelDetailsReducer,
    roomDetails: roomDetailsReducer,
    admin: AuthReducer
})

let initialState = {
    admin: {
        admin: {
            admin: localStorage.getItem("admin") ? localStorage.getItem("admin") : ""
        }
    }
};


const middleware = [thunk];
const store = createStore(reducer, initialState, composeWithDevTools(applyMiddleware(...middleware)));
export default store;