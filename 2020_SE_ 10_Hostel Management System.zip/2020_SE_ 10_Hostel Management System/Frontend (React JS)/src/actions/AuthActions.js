import { LOGIN, LOGOUT } from "../constants/Auth"
export const loginAdmin = () => async (dispatch) => {
    localStorage.setItem("admin", "AsadUllah");
    const admin = localStorage.getItem("admin");
    dispatch({
        type: LOGIN, payload: {
            admin
        }
    })
}


export const logoutAdmin = () => async (dispatch, getState) => {

    dispatch({
        type: LOGOUT,
    })
    localStorage.setItem("admin", "");
}


