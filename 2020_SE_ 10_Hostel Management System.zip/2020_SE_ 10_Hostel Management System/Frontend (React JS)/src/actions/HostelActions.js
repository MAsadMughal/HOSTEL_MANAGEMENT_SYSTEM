import axios from "axios";
import { REFRESH_STATE, HOSTEL_DETAILS_FAIL, HOSTEL_DETAILS_SUCCESS, HOSTEL_DETAILS_REQUEST, ALL_HOSTELS_FAIL, ALL_HOSTELS_SUCCESS, ALL_HOSTELS_REQUEST, CLEAR_ERRORS, NEW_HOSTEL_REQUEST, NEW_HOSTEL_SUCCESS, NEW_HOSTEL_FAIL } from "../constants/HostelConstants";

export const getHostels = () => async (dispatch) => {

    try {
        dispatch({ type: ALL_HOSTELS_REQUEST })
        let link = `/hostel`;

        const { data } = await axios.get(link);
        console.log(data);
        dispatch({
            type: ALL_HOSTELS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: ALL_HOSTELS_FAIL,
            payload: error.response.data.message
        })
    }
}
export const clearErrors = () => async (dispatch) => {
    dispatch({ type: CLEAR_ERRORS, })
}

export const refreshHostel = () => async (dispatch) => {
    dispatch({ type: REFRESH_STATE })
}




export const addNewHostel = (hostel) => async (dispatch) => {

    try {
        dispatch({ type: NEW_HOSTEL_REQUEST })
        let link = `/hostel`;

        const { data } = await axios.post(link, hostel);
        console.log(data);
        dispatch({
            type: NEW_HOSTEL_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: NEW_HOSTEL_FAIL,
            payload: error.response.data.message
        })
    }
}



export const getHostelDetails = (id) => async (dispatch) => {
    try {
        dispatch({ type: HOSTEL_DETAILS_REQUEST })
        let link = `/hostel/hostelId?hostelId=${id}`;

        const { data } = await axios.get(link);
        console.log(data);
        dispatch({
            type: HOSTEL_DETAILS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: HOSTEL_DETAILS_FAIL,
            payload: error.response.data.message
        })
    }
}


export const editYourHostel = (hostel) => async (dispatch) => {
    console.log(hostel);
    try {
        dispatch({ type: NEW_HOSTEL_REQUEST })
        let link = `/editHostel`;

        const { data } = await axios.put(link, hostel);
        console.log(data);
        dispatch({
            type: NEW_HOSTEL_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: NEW_HOSTEL_FAIL,
            payload: error.response.data.message
        })
    }
}


