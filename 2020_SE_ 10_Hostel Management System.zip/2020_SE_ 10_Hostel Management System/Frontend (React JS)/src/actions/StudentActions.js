import axios from "axios";
import { ALL_STUDENTS_FAIL, ALL_STUDENTS_SUCCESS, ALL_STUDENTS_REQUEST, ADD_STUDENT_FAIL, ADD_STUDENT_SUCCESS, ADD_STUDENT_REQUEST, STUDENT_DETAILS_FAIL, STUDENT_DETAILS_SUCCESS, STUDENT_DETAILS_REQUEST, CLEAR_ERRORS, REFRESH_STATE } from "../constants/studentConstants";


export const getStudents = (stuId = "", hostel = "", room = "") => async (dispatch) => {
    try {
        dispatch({ type: ALL_STUDENTS_REQUEST })
        let link = `/student`;
        if (stuId) {
            link = `/students/Id?studentId=${stuId}`;
        } else if (!stuId && hostel && !room) {
            link = `/students/hostelId?hostelId=${hostel}`
        } else if (!stuId && hostel && room) {
            link = `/students/hostelId/roomId?hostelId=${hostel}&roomId=${room}`;
        }


        const { data } = await axios.get(link);
        console.log(data);
        dispatch({
            type: ALL_STUDENTS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: ALL_STUDENTS_FAIL,
            payload: error.response.data.message
        })
    }
}



export const getStudentDetails = (stuId) => async (dispatch) => {
    try {
        dispatch({ type: STUDENT_DETAILS_REQUEST })
        let link = `/student/id?id=${stuId}`;

        const { data } = await axios.get(link);
        console.log(data);
        dispatch({
            type: STUDENT_DETAILS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: STUDENT_DETAILS_FAIL,
            payload: error.response.data.message
        })
    }
}
export const clearErrors = () => async (dispatch) => {
    dispatch({ type: CLEAR_ERRORS, })
}



export const addStudent = (student) => async (dispatch) => {

    try {
        dispatch({ type: ADD_STUDENT_REQUEST })
        let link = `/newStudent/id`;

        const { data } = await axios.post(link, student);
        console.log(data);
        dispatch({
            type: ADD_STUDENT_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: ADD_STUDENT_FAIL,
            payload: error.response.data.message
        })
    }
}




export const editStudent = (student) => async (dispatch) => {

    try {
        dispatch({ type: ADD_STUDENT_REQUEST })
        let link = `/editStudent`;

        const { data } = await axios.put(link, student);
        console.log(data);
        dispatch({
            type: ADD_STUDENT_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: ADD_STUDENT_FAIL,
            payload: error.response.data.message
        })
    }
}


export const refreshStudent = () => async (dispatch) => {
    dispatch({ type: REFRESH_STATE })
}
