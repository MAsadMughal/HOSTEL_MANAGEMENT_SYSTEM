import axios from "axios";
import {REFRESH_STATE, ROOM_DETAILS_FAIL, ROOM_DETAILS_SUCCESS, ROOM_DETAILS_REQUEST, ALL_ROOMS_FAIL, ALL_ROOMS_SUCCESS, ALL_ROOMS_REQUEST, CLEAR_ERRORS, NEW_ROOM_REQUEST, NEW_ROOM_SUCCESS, NEW_ROOM_FAIL } from "../constants/RoomConstants";

export const getRooms = (hostelId = "", room = "") => async (dispatch) => {

    try {
        dispatch({ type: ALL_ROOMS_REQUEST })
        let link = `/room`;
        if (!hostelId && !room) {
            link = "/room";
        } else if (hostelId && room ) {
            link = `/room/hostelId/roomId?hostelId=${hostelId}&roomId=${room}`;
        } else if (hostelId && !room) {
            link = `/Rooms/hostelId?hostelId=${hostelId}`;
        }


        const { data } = await axios.get(link);
        console.log(data);
        dispatch({
            type: ALL_ROOMS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: ALL_ROOMS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const clearErrors = () => async (dispatch) => {
    dispatch({ type: CLEAR_ERRORS })
}



export const addRoom = (room) => async (dispatch) => {

    try {
        console.log(room);
        dispatch({ type: NEW_ROOM_REQUEST })
        let link = `/room`;

        const { data } = await axios.post(link, room);
        console.log(data);
        dispatch({
            type: NEW_ROOM_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: NEW_ROOM_FAIL,
            payload: error.response.data.message
        })
    }
}


export const getRoomDetails = (hostelId, roomId) => async (dispatch) => {
    try {
        dispatch({ type: ROOM_DETAILS_REQUEST })
        let link = `/Editroom/hostelId/roomId?hostelId=${hostelId}&roomId=${roomId}`;

        const { data } = await axios.get(link);
        console.log(data);
        dispatch({
            type: ROOM_DETAILS_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: ROOM_DETAILS_FAIL,
            payload: error.response.data.message
        })
    }
}


export const editRoomDetails = (room) => async (dispatch) => {

    try {
        console.log(room);
        dispatch({ type: NEW_ROOM_REQUEST })
        let link = `/editRoom`;

        const { data } = await axios.put(link, room);
        console.log(data);
        dispatch({
            type: NEW_ROOM_SUCCESS,
            payload: data
        })
    } catch (error) {
        dispatch({
            type: NEW_ROOM_FAIL,
            payload: error.response.data.message
        })
    }
}
export const refreshRoom= () => async (dispatch) => {
    dispatch({ type: REFRESH_STATE })
}
