import { REFRESH_STATE, ROOM_DETAILS_FAIL, ROOM_DETAILS_SUCCESS, ROOM_DETAILS_REQUEST, ALL_ROOMS_FAIL, ALL_ROOMS_SUCCESS, ALL_ROOMS_REQUEST, CLEAR_ERRORS, NEW_ROOM_REQUEST, NEW_ROOM_SUCCESS, NEW_ROOM_FAIL } from "../constants/RoomConstants";



export const RoomReducer = ((state = { rooms: [] }, action) => {
    switch (action.type) {

        case ALL_ROOMS_REQUEST:
            return {
                loading: true,
                rooms: []
            }

        case ALL_ROOMS_SUCCESS:
            return {
                loading: false,
                rooms: action.payload,
            }

        case ALL_ROOMS_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;

    }
})





export const newRoomReducer = ((state = { newRoom: {} }, action) => {
    switch (action.type) {

        case NEW_ROOM_REQUEST:
            return {
                loading: true,
                newRoom: {}
            }

        case NEW_ROOM_SUCCESS:
            return {
                loading: false,
                newRoom: action.payload,
            }

        case NEW_ROOM_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

            case REFRESH_STATE:
                return {
                    ...state,
                    newRoom:{}
                }
    
        default:
            return state;

    }
})




export const roomDetailsReducer = ((state = { roomDetails: {} }, action) => {
    switch (action.type) {

        case ROOM_DETAILS_REQUEST:
            return {
                loading: true,
                roomDetails: {}
            }

        case ROOM_DETAILS_SUCCESS:
            return {
                loading: false,
                roomDetails: action.payload,
            }

        case ROOM_DETAILS_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
})
