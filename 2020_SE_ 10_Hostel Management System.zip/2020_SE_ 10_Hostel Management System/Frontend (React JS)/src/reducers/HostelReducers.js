import { REFRESH_STATE, HOSTEL_DETAILS_FAIL, HOSTEL_DETAILS_SUCCESS, HOSTEL_DETAILS_REQUEST, ALL_HOSTELS_FAIL, ALL_HOSTELS_SUCCESS, ALL_HOSTELS_REQUEST, CLEAR_ERRORS, NEW_HOSTEL_REQUEST, NEW_HOSTEL_SUCCESS, NEW_HOSTEL_FAIL } from "../constants/HostelConstants";



export const HostelReducer = ((state = { hostels: [] }, action) => {
    switch (action.type) {

        case ALL_HOSTELS_REQUEST:
            return {
                loading: true,
                hostels: []
            }

        case ALL_HOSTELS_SUCCESS:
            return {
                loading: false,
                hostels: action.payload,
            }

        case ALL_HOSTELS_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;

    }
})



export const newHostelReducer = ((state = { newHostel: {} }, action) => {
    switch (action.type) {

        case NEW_HOSTEL_REQUEST:
            return {
                loading: true,
                newHostel: {}
            }

        case NEW_HOSTEL_SUCCESS:
            return {
                loading: false,
                newHostel: action.payload,
            }

        case NEW_HOSTEL_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        case REFRESH_STATE:
            return {
                ...state,
                newHostel: {}
            }

        default:
            return state;

    }
})




export const hostelDetailsReducer = ((state = { hostelDetails: {} }, action) => {
    switch (action.type) {

        case HOSTEL_DETAILS_REQUEST:
            return {
                loading: true,
                hostelDetails: {}
            }

        case HOSTEL_DETAILS_SUCCESS:
            return {
                loading: false,
                hostelDetails: action.payload,
            }

        case HOSTEL_DETAILS_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
})
