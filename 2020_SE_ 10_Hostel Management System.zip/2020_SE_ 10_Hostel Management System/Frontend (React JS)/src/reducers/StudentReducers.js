import {REFRESH_STATE, ALL_STUDENTS_FAIL, ALL_STUDENTS_SUCCESS, ALL_STUDENTS_REQUEST, ADD_STUDENT_FAIL, ADD_STUDENT_SUCCESS, ADD_STUDENT_REQUEST, STUDENT_DETAILS_FAIL, STUDENT_DETAILS_SUCCESS, STUDENT_DETAILS_REQUEST, CLEAR_ERRORS } from "../constants/studentConstants";



export const studentReducer = ((state = { students: [] }, action) => {
    switch (action.type) {

        case ALL_STUDENTS_REQUEST:
            return {
                loading: true,
                students: []
            }

        case ALL_STUDENTS_SUCCESS:
            return {
                loading: false,
                students: action.payload,
            }

        case ALL_STUDENTS_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;

    }
})




export const studentDetailsReducer = ((state = { studentDetails: {} }, action) => {
    switch (action.type) {

        case STUDENT_DETAILS_REQUEST:
            return {
                loading: true,
                studentDetails: {}
            }

        case STUDENT_DETAILS_SUCCESS:
            return {
                loading: false,
                studentDetails: action.payload,
            }

        case STUDENT_DETAILS_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }
        
    
        default:
            return state;
    }
})






export const newStudentReducer = ((state = { newStudent: {} }, action) => {
    switch (action.type) {

        case ADD_STUDENT_REQUEST:
            return {
                loading: true,
                newStudent: {}
            }

        case ADD_STUDENT_SUCCESS:
            return {
                loading: false,
                newStudent: action.payload,
            }

        case ADD_STUDENT_FAIL:
            return {
                loading: false,
                error: action.payload,
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }
            case REFRESH_STATE:
                return {
                    ...state,
                    newStudent:{}
                }

        default:
            return state;

    }
})


