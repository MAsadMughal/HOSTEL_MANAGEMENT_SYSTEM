import { LOGIN, LOGOUT } from "../constants/Auth";

export const AuthReducer = (state = { admin: {} }, action) => {
    switch (action.type) {
        case LOGIN:
            return {
                admin: action.payload
            }
        case LOGOUT:
            return {
                admin: {}
            }
        default:
            return state;
    }
}